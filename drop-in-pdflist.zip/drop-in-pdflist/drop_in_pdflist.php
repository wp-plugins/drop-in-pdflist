<?php
/*
Plugin Name: Drop-in .pdfList
Plugin URI: URI: http://brut.bukve.net/?p=200
Plugin demo URI: http://brut.bukve.net/?p=200, http://specom.si/wp/?page_id=20
Plugin download URI: http://brut.bukve.net/wordpress/wp-content/uploads/drop-in-pdflist.zip
Description: Creates a list of thumbnails linking to .pdf attachments. Thumbnails are generated on-the-fly by ImageMagick (first time only)
Author: brut
Version: 0.03
Author URI: brut.bukve.net
Generated At: www.wp-fun.co.uk;

INSTRUCTIONS

1) Extract *drop-in-pdflist* folder from *drop_in_pdflist.zip* into Wordpress plugin folder
2) Activate *Drop-in .pdfList* from /wp-admin/plugins.php
3) Opload your .pdf files wih post or page
4) Insert *[drop_in_pdf]* shortcode whereever your thumbnails should be displayed. 
5) Preview your page to force first-time thumbnail generation.
6) *[drop_in_pdf]* shortcode inserts thumbnails for last 3 .pdf files, if you want more thumbs, use *[drop_in_pdf num=x]* shortcode where x represents the number of thumbnails
7) to display .pdf files from another post, use *[drop_in_pdf id=x]* shortcode where x represents ID number of post with .pdf files

NOTICE 

Drop-in .pdfList creates thumbnail images of .pdf documents using ImageMagick (http://www.imagemagick.org/script/index.php)
*wp-content/plugins/drop-in-pdflist/pdf.png* is used to produce semi-transparet thumbnail background, if your thumbnails have dimensions other than 212x300px, replace this file with your own

LICENSE

drop_in_pdflist.php
Copyright (C) 2008 brut
brut07@gmail.com
http://brut.bukve.net/

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
*	User settings: change to customize thumbnail size and/or appearance
*/
/* inline .pdf thumbnail style, create your own pdf.png if you change thumbnail dimensions  */
$_pdfStyle="<style>.pdf { float: left; clear: none; margin: -20px; padding: 10px; background: url(".WP_PLUGIN_URL."/drop-in-pdflist/pdf.png);}</style>";
/* ImageMagick thumbnail creation parameters, 212x300 are actual thumbnail dimensions, check http://www.imagemagick.org/ for more */
$_pdfThumbGen="-thumbnail '250x300' -extent '212x300' ";	
/* inline .zip thumbnail style  */
$_zipStyle="<style>.zip { float: left; clear: none; margin: 0px; margin-right: 16px; }</style>";
/* .zip thumbnail image from Aqua Gloss Icons set (http://www.dezinerfolio.com/2007/02/25/free-aqua-gloss-icons) of http://www.dezinerfolio.com */
$_zipIcon=WP_PLUGIN_URL."/drop-in-pdflist/zip.png";
/*
*	END User settings, $_pdfStyle, $_pdfThumbGen, $_zipStyle, $_zipIcon
*/

if (!class_exists('drop_in_pdflist')) {
    class drop_in_pdflist	{
		function drop_in_pdflist(){
			$this->__construct();
			}
		function __construct(){
			if ( function_exists( 'add_shortcode' ) ) {
				add_shortcode('drop_in_pdf', array( &$this , 'drop_in_pdf_shortcode' ) );
				add_shortcode('drop_in_zip', array( &$this , 'drop_in_zip_shortcode' ) );
				}
			}
		function drop_in_zip_shortcode($_in) {
			global $post, $_zipStyle, $_zipIcon;
			if(!isset($_in['id'])){$_in['id']=$post->ID;}
			$_attachments = get_children( "post_type=attachment&orderby=menu_order&order=ASC&post_parent=".
				$_in['id']."&numberposts=".abs($_in['num'])."&post_mime_type=application/zip");
			if($_attachments !== false ){
				$_retVal=$_zipStyle;
				foreach($_attachments as $_zip){
					$_retVal.="<a class=zip href=".$_zip->guid." /><img style='border: 0px;' title='Download ".$_zip->post_title."' alt='Download ".$_zip->post_title."' src=$_zipIcon /></a>";
					}
				} 
			return $_retVal;
			}
		function drop_in_pdf_shortcode($_in) {
			global $post, $current_user, $_pdfStyle, $_pdfThumbGen;
			if(!isset($_in['num'])){$_in['num']=3;}
			if(!isset($_in['id'])){$_in['id']=$post->ID;}
			$_adminReport='';
			get_currentuserinfo();			
			$_attachments = get_children( "post_type=attachment&orderby=menu_order&order=ASC&post_parent=".
				$_in['id']."&numberposts=".abs($_in['num'])."&post_mime_type=application/pdf");
			if($_attachments !== false ){
				$_retVal=$_pdfStyle;
				foreach($_attachments as $_pdf){
					$_file=str_replace('index.php','',$_SERVER["SCRIPT_FILENAME"]).str_replace($_SERVER['SCRIPT_URI'],'',$_pdf->guid);
					$_thumb=str_replace('.pdf','.jpg',$_file);
					if(!file_exists($_thumb)){
						exec("convert ".$_file."[0] $_pdfThumbGen $_thumb",$_log,$_result);
						if($current_user->user_level==10){
							if($_result==0){$_adminReport.=$_pdf->post_title." thumbnail generated, ";}
							else{$_adminReport.="ERROR, check for <a href=http://www.imagemagick.org/>ImageMagick</a><br>".implode('<br>',$_log)." Code: ".$_result." | ";}
							}
						}
					$_retVal.="<a class=pdf title='".$_pdf->post_title."' alt='".$_pdf->post_title."' href=".$_pdf->guid." /><img src=".str_replace('.pdf','.jpg',$_pdf->guid)." /></a>";
					}
				} 
			return "<b style='color: #a00;'>$_adminReport</b><br>".$_retVal."<br style='clear: both;'><br>";
			}
	    }
	}

if (class_exists('drop_in_pdflist')) {
	$drop_in_pdflist = new drop_in_pdflist();
	}

/* **************************************************************************** */
/* **************************************************************************** */
/* **************************************************************************** */
/* **************************************************************************** */
/* **************************************************************************** */

function _all_shit($_in, $_phpinfo=false){
	/* usage: 
	_all_shit('head');
	$_vars = get_defined_vars();
	echo "<pre>";var_export($_vars);echo "</pre>";
	_all_shit('foot'); // _all_shit('foot',true); // _all_shit('die',true); 
	*/	
	if($_in=='head')	{
		echo "<div title='Show all shit ... ' onclick=if(this.nextSibling.style.display==''){this.nextSibling.style.display='none';}else{this.nextSibling.style.display='';} style='cursor: pointer; display:inline; background: #f9f0b3; color: #bfb155; padding: 3px; float: right; clear:none; ' >"
				."&nbsp;&darr;&nbsp;</div><div style='display:none; border=1px solid #0a0;padding: 5px'>"
				."<h1>get_defined_vars()</h1>";
		}
	elseif($_in=='foot' || $_in=='die'){
		if($_phpinfo){
			echo "<hr style='height:5px; background: #0a0; width: 60%;'>"
					."<div onclick=if(this.nextSibling.style.display==''){this.nextSibling.style.display='none';}else{this.nextSibling.style.display='';} style='cursor: pointer; display:inline; background: #f9f0b3; color: #bfb155; padding: 3px;' >"
					." Show phpinfo() </div><div style='display:none; border=1px solid #0a0;padding: 5px'><span>";
			phpinfo();
			echo "</span></div>";
			}
		echo "</div>";
		}
	if($_in=='die'){	
		die('_end');
		}
	}
?>
